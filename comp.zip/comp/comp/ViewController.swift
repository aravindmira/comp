//
//  ViewController.swift
//  comp
//
//  Created by 8KMILES on 20/12/19.
//  Copyright © 2019 8KMILES. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Textlbl: UILabel!
    var arrofstr = [String]()
    var mediatype = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
    
        changeStrToArray(fullString: "start1[asdasd]end1,asdasfasf[asdas]adfaf,dfjhsdjfsjdf[sdfsdf]sdfjhfdjg")
        
        var fullString = NSMutableAttributedString()
//        for i in(0...(arrofstr.count)-1){
//            print (i)
//
//            fullString.append(NSAttributedString(string: arrofstr[i]))
//            let image1Attachment = NSTextAttachment()
//            image1Attachment.image = UIImage(named: "search.png")
//            let image1String = NSAttributedString(attachment: image1Attachment)
//            fullString.append(image1String)
//           // fullString.append(NSAttributedString(string: arrofstr[i+1]))
//
//
//
//
//        }
//         Textlbl.attributedText = fullString

    }
    func changeStrToArray(fullString:String)  {
       print(fullString)
         var CustAttriStr = NSMutableAttributedString()
        let fullNameArr = fullString.components(separatedBy: "[")
        for i in(0...fullNameArr.count-1){
            let subString = fullNameArr[i]
            let arrsub = subString.components(separatedBy: "]")
            if i != 0{
                
            let image1Attachment = NSTextAttachment()
            image1Attachment.image = UIImage(named: "search.png")
            image1Attachment.setImageHeight(height: 20)
            let image1String = NSAttributedString(attachment: image1Attachment)
            CustAttriStr.append(image1String)
                
            }
            if subString.range(of: "]") != nil {
                let fullName12 = subString.components(separatedBy: "]")
                print(fullName12[1])
                arrofstr.append(fullName12[1])
                CustAttriStr.append(NSAttributedString(string: fullName12[1]))
                
            } else {
                //print(fullNameArr[0])
                arrofstr.append(fullNameArr[0])
                 CustAttriStr.append(NSAttributedString(string: fullNameArr[0]))
              
            }
            if arrsub.count>=1
            {
                if(i != 0){
                    print("123456789 \(arrsub[0])")
                    mediatype.append(arrsub[0])
                }
            }
            
        }
        
        print(" as array of \(arrofstr)")
        print(" as array media \(mediatype)")
        Textlbl.attributedText = CustAttriStr

    }


}

extension NSTextAttachment {
    func setImageHeight(height: CGFloat) {
        guard let image = image else { return }
        let ratio = image.size.width / image.size.height
        
        bounds = CGRect(x: bounds.origin.x, y: bounds.origin.y, width: ratio * height, height: height)
    }
}

